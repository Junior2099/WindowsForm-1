namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int peso, altura, resultado;

            peso = (int)Convert.ToDouble(peso.Text);
            altura = (int)Convert.ToDouble(altura.Text);

            resultado = peso / (altura * altura);

            MessageBox.Show("O resultado � " + resultado);


        }
    }
}
