﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtValor1 = new TextBox();
            txtValor2 = new TextBox();
            txtResultado = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            btnCalcular = new Button();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            label5 = new Label();
            SuspendLayout();
            // 
            // txtValor1
            // 
            txtValor1.HideSelection = false;
            txtValor1.Location = new Point(32, 104);
            txtValor1.Name = "txtValor1";
            txtValor1.Size = new Size(100, 23);
            txtValor1.TabIndex = 0;
            txtValor1.UseWaitCursor = true;
            // 
            // txtValor2
            // 
            txtValor2.Location = new Point(175, 104);
            txtValor2.Name = "txtValor2";
            txtValor2.Size = new Size(100, 23);
            txtValor2.TabIndex = 1;
            txtValor2.UseWaitCursor = true;
            // 
            // txtResultado
            // 
            txtResultado.Location = new Point(78, 167);
            txtResultado.Name = "txtResultado";
            txtResultado.Size = new Size(154, 23);
            txtResultado.TabIndex = 2;
            txtResultado.UseWaitCursor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(32, 86);
            label1.Name = "label1";
            label1.Size = new Size(42, 15);
            label1.TabIndex = 3;
            label1.Text = "Valor 1";
            label1.UseWaitCursor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(175, 86);
            label2.Name = "label2";
            label2.Size = new Size(42, 15);
            label2.TabIndex = 4;
            label2.Text = "Valor 2";
            label2.UseWaitCursor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(123, 149);
            label3.Name = "label3";
            label3.Size = new Size(59, 15);
            label3.TabIndex = 5;
            label3.Text = "Resultado";
            label3.UseWaitCursor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 15F);
            label4.Location = new Point(157, 104);
            label4.Name = "label4";
            label4.Size = new Size(0, 28);
            label4.TabIndex = 6;
            label4.UseWaitCursor = true;
            label4.Click += label4_Click;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(66, 196);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(81, 29);
            btnCalcular.TabIndex = 8;
            btnCalcular.Text = "Somar";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.UseWaitCursor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // button1
            // 
            button1.Location = new Point(66, 231);
            button1.Name = "button1";
            button1.Size = new Size(81, 29);
            button1.TabIndex = 9;
            button1.Text = "Subtrair";
            button1.UseVisualStyleBackColor = true;
            button1.UseWaitCursor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(162, 231);
            button2.Name = "button2";
            button2.Size = new Size(81, 29);
            button2.TabIndex = 10;
            button2.Text = "Mod";
            button2.UseVisualStyleBackColor = true;
            button2.UseWaitCursor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(162, 196);
            button3.Name = "button3";
            button3.Size = new Size(81, 29);
            button3.TabIndex = 11;
            button3.Text = "Dividir";
            button3.UseVisualStyleBackColor = true;
            button3.UseWaitCursor = true;
            button3.Click += button3_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 20F);
            label5.Location = new Point(3, 26);
            label5.Name = "label5";
            label5.Size = new Size(297, 37);
            label5.TabIndex = 12;
            label5.Text = "Calculadora Simples C#";
            label5.UseWaitCursor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(299, 288);
            Controls.Add(label5);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(btnCalcular);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtResultado);
            Controls.Add(txtValor2);
            Controls.Add(txtValor1);
            Name = "Form1";
            Text = "Form1";
            UseWaitCursor = true;
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtValor1;
        private TextBox txtValor2;
        private TextBox txtResultado;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button btnCalcular;
        private Button button1;
        private Button button2;
        private Button button3;
        private Label label5;
    }
}
