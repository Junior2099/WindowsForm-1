namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            int valor1, valor2, resultado;

            valor1 = Convert.ToInt32(txtValor1.Text);
            valor2 = Convert.ToInt32(txtValor2.Text);

            resultado = valor1 + valor2;


            txtResultado.Text = resultado.ToString();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


            int valor1, valor2, resultado;

            valor1 = Convert.ToInt32(txtValor1.Text);
            valor2 = Convert.ToInt32(txtValor2.Text);

            resultado = valor1 - valor2;


            txtResultado.Text = resultado.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {


            int valor1, valor2, resultado;

            valor1 = Convert.ToInt32(txtValor1.Text);
            valor2 = Convert.ToInt32(txtValor2.Text);

            resultado = valor1 % valor2;


            txtResultado.Text = resultado.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {


            int valor1, valor2, resultado;

            valor1 = Convert.ToInt32(txtValor1.Text);
            valor2 = Convert.ToInt32(txtValor2.Text);

            resultado = valor1 / valor2;


            txtResultado.Text = resultado.ToString();
        }
    }
}
